package com.developerrr.fitnesstracker.models;

//Wird nie verwendet
public class Step {

    CharSequence fullDate;
    int day;
    String steps;
    String dayName;
    int month;


}
