package com.developerrr.fitnesstracker.models;

//Wird nie verwendet
public class Constant {

    public static final int NETWORK_ID=405;
}
